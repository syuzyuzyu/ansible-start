import React from 'react';
import ReactDOM from 'react-dom';

ReactDOM.render(
<div>hello Spa!!!!!</div>,
document.getElementById('app')
);
